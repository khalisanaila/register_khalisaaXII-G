document.getElementById("RegisterForm").addEventListener("submit", function(e) {
      e.preventDefault();

      const nama = document.getElementById("nama").value;
      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;
      const nomorHp = document.getElementById("nomor_hp").value;
      const tanggalLahir = document.getElementById("tanggal_lahir").value;

      const table = document.getElementById("datatabel").getElementsByTagName("tbody")[0];
      const newRow = table.insertRow();

      newRow.insertCell(0).textContent = nama;
      newRow.insertCell(1).textContent = email;
      newRow.insertCell(2).textContent = password;
      newRow.insertCell(3).textContent = nomorHp;
      newRow.insertCell(4).textContent = tanggalLahir;

      document.getElementById("RegisterForm").reset();
    });qq